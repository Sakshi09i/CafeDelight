import { create } from 'zustand'

export interface User {
  id: string
  name: string
  email: string
  phone?: string
  role?: 'USER' | 'ADMIN'
}

interface AuthState {
  user: User | null
  token: string | null
  isAuthenticated: boolean
  login: (user: Partial<User> & { _id?: string }, token: string) => void
  logout: () => void
  updateUser: (data: Partial<User>) => void
}

export const useAuth = create<AuthState>((set) => ({
  user: localStorage.getItem('user')
    ? JSON.parse(localStorage.getItem('user')!)
    : null,

  token: localStorage.getItem('token'),

  isAuthenticated: Boolean(localStorage.getItem('token')),

  login: (user, token) => {
    const normalizedUser: User = {
      id: user.id || user._id!,
      name: user.name!,
      email: user.email!,
      phone: user.phone,
      role: user.role || 'USER',
    }

    localStorage.setItem('user', JSON.stringify(normalizedUser))
    localStorage.setItem('token', token)

    set({
      user: normalizedUser,
      token,
      isAuthenticated: true,
    })
  },

  logout: () => {
    localStorage.removeItem('user')
    localStorage.removeItem('token')

    set({
      user: null,
      token: null,
      isAuthenticated: false,
    })
  },

  updateUser: (data) =>
    set((state) => {
      if (!state.user) return state

      const updatedUser = { ...state.user, ...data }
      localStorage.setItem('user', JSON.stringify(updatedUser))

      return { user: updatedUser }
    }),
}))
