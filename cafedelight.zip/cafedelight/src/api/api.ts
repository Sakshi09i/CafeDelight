const API_BASE = 'http://localhost:5000'

export async function apiPost(url: string, data?: any) {
  const token = localStorage.getItem('token')

  const res = await fetch(API_BASE + url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
    },
    body: JSON.stringify(data),
  })

  const json = await res.json()
  if (!res.ok) throw new Error(json.message || 'Request failed')
  return json
}

export async function apiGet(url: string) {
  const token = localStorage.getItem('token')

  const res = await fetch(API_BASE + url, {
    method: 'GET',
    headers: {
      ...(token && { Authorization: `Bearer ${token}` }),
    },
  })

  const json = await res.json()
  if (!res.ok) throw new Error(json.message || 'Request failed')
  return json
}
