import { Navigate, Outlet } from 'react-router-dom'
import { useAuth } from '../stores/auth'

interface Props {
  allowedRoles?: Array<'USER' | 'ADMIN'>
}

export function ProtectedRoute({ allowedRoles }: Props) {
  const { isAuthenticated, user } = useAuth()

  // 🔐 Not logged in
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />
  }

  // 🔒 Role check (if roles provided)
  if (allowedRoles && !allowedRoles.includes(user.role!)) {
    return <Navigate to="/unauthorized" replace />
  }

  return <Outlet />
}
